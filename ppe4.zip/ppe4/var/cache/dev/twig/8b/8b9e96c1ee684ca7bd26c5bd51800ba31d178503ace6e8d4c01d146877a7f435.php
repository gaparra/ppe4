<?php

/* @EasyAdmin/default/field_text.html.twig */
class __TwigTemplate_0bef50ad9b233f0459c81ff471ac2a64c40ffc3a3567ac3340050090d573ef57 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3235fe09655114b66932611b26932ba14a9fe076f5a880a594e92f5bc18f08a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3235fe09655114b66932611b26932ba14a9fe076f5a880a594e92f5bc18f08a2->enter($__internal_3235fe09655114b66932611b26932ba14a9fe076f5a880a594e92f5bc18f08a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@EasyAdmin/default/field_text.html.twig"));

        $__internal_40197509bdc89cb2be57b14dc3c029fcb0836a6d8085923263654f98dd5163a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40197509bdc89cb2be57b14dc3c029fcb0836a6d8085923263654f98dd5163a9->enter($__internal_40197509bdc89cb2be57b14dc3c029fcb0836a6d8085923263654f98dd5163a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@EasyAdmin/default/field_text.html.twig"));

        // line 1
        if (((isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 1, $this->getSourceContext()); })()) == "show")) {
            // line 2
            echo "    ";
            echo nl2br(twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 2, $this->getSourceContext()); })()), "html", null, true));
            echo "
";
        } else {
            // line 4
            echo "    ";
            echo twig_escape_filter($this->env, $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->truncateText($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 4, $this->getSourceContext()); })())), "html", null, true);
            echo "
";
        }
        
        $__internal_3235fe09655114b66932611b26932ba14a9fe076f5a880a594e92f5bc18f08a2->leave($__internal_3235fe09655114b66932611b26932ba14a9fe076f5a880a594e92f5bc18f08a2_prof);

        
        $__internal_40197509bdc89cb2be57b14dc3c029fcb0836a6d8085923263654f98dd5163a9->leave($__internal_40197509bdc89cb2be57b14dc3c029fcb0836a6d8085923263654f98dd5163a9_prof);

    }

    public function getTemplateName()
    {
        return "@EasyAdmin/default/field_text.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  27 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if view == 'show' %}
    {{ value|nl2br }}
{% else %}
    {{ value|easyadmin_truncate }}
{% endif %}
", "@EasyAdmin/default/field_text.html.twig", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\vendor\\javiereguiluz\\easyadmin-bundle\\src\\Resources\\views\\default\\field_text.html.twig");
    }
}
