<?php

/* @Twig/images/icon-minus-square-o.svg */
class __TwigTemplate_d9a3d9f0f761bbcaf318a497f0d50a390ef338f62ef091afc8e1213205d42c7a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e6fd61717f05dc0b00c80d0e1e134025737bae2b11417a2705a5753bb94a3f28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6fd61717f05dc0b00c80d0e1e134025737bae2b11417a2705a5753bb94a3f28->enter($__internal_e6fd61717f05dc0b00c80d0e1e134025737bae2b11417a2705a5753bb94a3f28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square-o.svg"));

        $__internal_47a0fbe2e5e529951ab71d8643f99761ae770d73215d5e3eb42a803b3af971a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_47a0fbe2e5e529951ab71d8643f99761ae770d73215d5e3eb42a803b3af971a6->enter($__internal_47a0fbe2e5e529951ab71d8643f99761ae770d73215d5e3eb42a803b3af971a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square-o.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1344 800v64q0 14-9 23t-23 9H480q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h832q14 0 23 9t9 23zm128 448V416q0-66-47-113t-113-47H480q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113zm128-832v832q0 119-84.5 203.5T1312 1536H480q-119 0-203.5-84.5T192 1248V416q0-119 84.5-203.5T480 128h832q119 0 203.5 84.5T1600 416z\"/></svg>
";
        
        $__internal_e6fd61717f05dc0b00c80d0e1e134025737bae2b11417a2705a5753bb94a3f28->leave($__internal_e6fd61717f05dc0b00c80d0e1e134025737bae2b11417a2705a5753bb94a3f28_prof);

        
        $__internal_47a0fbe2e5e529951ab71d8643f99761ae770d73215d5e3eb42a803b3af971a6->leave($__internal_47a0fbe2e5e529951ab71d8643f99761ae770d73215d5e3eb42a803b3af971a6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square-o.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1344 800v64q0 14-9 23t-23 9H480q-14 0-23-9t-9-23v-64q0-14 9-23t23-9h832q14 0 23 9t9 23zm128 448V416q0-66-47-113t-113-47H480q-66 0-113 47t-47 113v832q0 66 47 113t113 47h832q66 0 113-47t47-113zm128-832v832q0 119-84.5 203.5T1312 1536H480q-119 0-203.5-84.5T192 1248V416q0-119 84.5-203.5T480 128h832q119 0 203.5 84.5T1600 416z\"/></svg>
", "@Twig/images/icon-minus-square-o.svg", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\vendor\\symfony\\twig-bundle\\Resources\\views\\images\\icon-minus-square-o.svg");
    }
}
