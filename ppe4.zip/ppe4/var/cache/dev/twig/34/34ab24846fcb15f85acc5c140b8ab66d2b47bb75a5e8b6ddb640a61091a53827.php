<?php

/* @EasyAdmin/default/field_email.html.twig */
class __TwigTemplate_b33e2a95b4b3e9dc6110548cc648d6f8f012d008bfc983246430e6dac8cf966b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_183b4b266ae53a64666c0a36172a459085a1b6c1d9eb12d58689e53f0260a174 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_183b4b266ae53a64666c0a36172a459085a1b6c1d9eb12d58689e53f0260a174->enter($__internal_183b4b266ae53a64666c0a36172a459085a1b6c1d9eb12d58689e53f0260a174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@EasyAdmin/default/field_email.html.twig"));

        $__internal_e1722dba86918b068e17e0771c766c6b05ac8eb4fe04bf06925cc10dbeb238fa = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e1722dba86918b068e17e0771c766c6b05ac8eb4fe04bf06925cc10dbeb238fa->enter($__internal_e1722dba86918b068e17e0771c766c6b05ac8eb4fe04bf06925cc10dbeb238fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@EasyAdmin/default/field_email.html.twig"));

        // line 1
        if (((isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 1, $this->getSourceContext()); })()) == "show")) {
            // line 2
            echo "    <a href=\"mailto:";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 2, $this->getSourceContext()); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 2, $this->getSourceContext()); })()), "html", null, true);
            echo "</a>
";
        } else {
            // line 4
            echo "    <a href=\"mailto:";
            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 4, $this->getSourceContext()); })()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->truncateText($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 4, $this->getSourceContext()); })())), "html", null, true);
            echo "</a>
";
        }
        
        $__internal_183b4b266ae53a64666c0a36172a459085a1b6c1d9eb12d58689e53f0260a174->leave($__internal_183b4b266ae53a64666c0a36172a459085a1b6c1d9eb12d58689e53f0260a174_prof);

        
        $__internal_e1722dba86918b068e17e0771c766c6b05ac8eb4fe04bf06925cc10dbeb238fa->leave($__internal_e1722dba86918b068e17e0771c766c6b05ac8eb4fe04bf06925cc10dbeb238fa_prof);

    }

    public function getTemplateName()
    {
        return "@EasyAdmin/default/field_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 4,  27 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if view == 'show' %}
    <a href=\"mailto:{{ value }}\">{{ value }}</a>
{% else %}
    <a href=\"mailto:{{ value }}\">{{ value|easyadmin_truncate }}</a>
{% endif %}
", "@EasyAdmin/default/field_email.html.twig", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\vendor\\javiereguiluz\\easyadmin-bundle\\src\\Resources\\views\\default\\field_email.html.twig");
    }
}
