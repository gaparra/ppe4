<?php

/* home/index.html.twig */
class __TwigTemplate_598b7c32cc6f76a09302ea38ae00fe1a519f159ba217ea4c52fd9cabfed6b371 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'bouton' => array($this, 'block_bouton'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4cde690104dcfcb6cc6676b96212eae652e3c1f7e0e6873fc153383ec6cdf779 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4cde690104dcfcb6cc6676b96212eae652e3c1f7e0e6873fc153383ec6cdf779->enter($__internal_4cde690104dcfcb6cc6676b96212eae652e3c1f7e0e6873fc153383ec6cdf779_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $__internal_912c687ffcc7a7d2c97014199f17242856dd094a5b06fbfddbecfe9d70a2840e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_912c687ffcc7a7d2c97014199f17242856dd094a5b06fbfddbecfe9d70a2840e->enter($__internal_912c687ffcc7a7d2c97014199f17242856dd094a5b06fbfddbecfe9d70a2840e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4cde690104dcfcb6cc6676b96212eae652e3c1f7e0e6873fc153383ec6cdf779->leave($__internal_4cde690104dcfcb6cc6676b96212eae652e3c1f7e0e6873fc153383ec6cdf779_prof);

        
        $__internal_912c687ffcc7a7d2c97014199f17242856dd094a5b06fbfddbecfe9d70a2840e->leave($__internal_912c687ffcc7a7d2c97014199f17242856dd094a5b06fbfddbecfe9d70a2840e_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_35c5db5837c6fed5220f43d74447a7be656bea31818f8dff31191df3cbdb9766 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35c5db5837c6fed5220f43d74447a7be656bea31818f8dff31191df3cbdb9766->enter($__internal_35c5db5837c6fed5220f43d74447a7be656bea31818f8dff31191df3cbdb9766_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7f99ca85ea194b835a1476c2bc35df8f802709b021c260f33266840f5ec38f3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f99ca85ea194b835a1476c2bc35df8f802709b021c260f33266840f5ec38f3d->enter($__internal_7f99ca85ea194b835a1476c2bc35df8f802709b021c260f33266840f5ec38f3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "    <h1> Exemple d'utilisation de la sécurité</h1>
    ";
        // line 6
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 7
            echo "        <p>Username: ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 7, $this->getSourceContext()); })()), "user", array()), "username", array()), "html", null, true);
            echo "</p>
    ";
        } else {
            // line 9
            echo "        <p>Vous n'êtes pas authentifié.</p>
    ";
        }
        
        $__internal_7f99ca85ea194b835a1476c2bc35df8f802709b021c260f33266840f5ec38f3d->leave($__internal_7f99ca85ea194b835a1476c2bc35df8f802709b021c260f33266840f5ec38f3d_prof);

        
        $__internal_35c5db5837c6fed5220f43d74447a7be656bea31818f8dff31191df3cbdb9766->leave($__internal_35c5db5837c6fed5220f43d74447a7be656bea31818f8dff31191df3cbdb9766_prof);

    }

    // line 15
    public function block_bouton($context, array $blocks = array())
    {
        $__internal_4eb3a824107e3d18bcf868b1587434237ef75969092c03457eebc4ade3d25fea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4eb3a824107e3d18bcf868b1587434237ef75969092c03457eebc4ade3d25fea->enter($__internal_4eb3a824107e3d18bcf868b1587434237ef75969092c03457eebc4ade3d25fea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bouton"));

        $__internal_ec872558926c7b5df4831d833783439d667250f5c3e2e00869b72881d01c4c59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ec872558926c7b5df4831d833783439d667250f5c3e2e00869b72881d01c4c59->enter($__internal_ec872558926c7b5df4831d833783439d667250f5c3e2e00869b72881d01c4c59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "bouton"));

        // line 16
        echo "    ";
        if ( !$this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 17
            echo "        <a class=\"nav-link float-right\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
            echo "\">Se connecter
    ";
        } else {
            // line 19
            echo "        <a class=\"nav-link float-right\" href=\"";
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("logout");
            echo "\">Se déconnecter
    ";
        }
        
        $__internal_ec872558926c7b5df4831d833783439d667250f5c3e2e00869b72881d01c4c59->leave($__internal_ec872558926c7b5df4831d833783439d667250f5c3e2e00869b72881d01c4c59_prof);

        
        $__internal_4eb3a824107e3d18bcf868b1587434237ef75969092c03457eebc4ade3d25fea->leave($__internal_4eb3a824107e3d18bcf868b1587434237ef75969092c03457eebc4ade3d25fea_prof);

    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 19,  85 => 17,  82 => 16,  73 => 15,  61 => 9,  55 => 7,  53 => 6,  50 => 5,  41 => 4,  11 => 2,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{# empty Twig template #}
{%  extends \"base.html.twig\" %}

{% block body %}
    <h1> Exemple d'utilisation de la sécurité</h1>
    {% if is_granted('IS_AUTHENTICATED_FULLY')%}
        <p>Username: {{app.user.username}}</p>
    {%else%}
        <p>Vous n'êtes pas authentifié.</p>
    {%endif%}
{%endblock body%}



{% block bouton %}
    {% if not is_granted('IS_AUTHENTICATED_FULLY')%}
        <a class=\"nav-link float-right\" href=\"{{path(\"login\")}}\">Se connecter
    {%else%}
        <a class=\"nav-link float-right\" href=\"{{path(\"logout\")}}\">Se déconnecter
    {%endif%}
{% endblock bouton %}", "home/index.html.twig", "C:\\Users\\g.parra\\projetSf4\\ppe4\\templates\\home\\index.html.twig");
    }
}
