<?php

/* login/login.html.twig */
class __TwigTemplate_6e20e04f9afe6b22cb271bcd032b2e641630a9940bdb1ada24994ac5c7801611 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "login/login.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9bf9ee999b63b53cc416e2aa255b0edbb0f898ac6346e9e4581d4049c4e8b04a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9bf9ee999b63b53cc416e2aa255b0edbb0f898ac6346e9e4581d4049c4e8b04a->enter($__internal_9bf9ee999b63b53cc416e2aa255b0edbb0f898ac6346e9e4581d4049c4e8b04a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "login/login.html.twig"));

        $__internal_552b0d32df3496339e82e7db97221ba502e3cb16803bf4f875319763b5050784 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_552b0d32df3496339e82e7db97221ba502e3cb16803bf4f875319763b5050784->enter($__internal_552b0d32df3496339e82e7db97221ba502e3cb16803bf4f875319763b5050784_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "login/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9bf9ee999b63b53cc416e2aa255b0edbb0f898ac6346e9e4581d4049c4e8b04a->leave($__internal_9bf9ee999b63b53cc416e2aa255b0edbb0f898ac6346e9e4581d4049c4e8b04a_prof);

        
        $__internal_552b0d32df3496339e82e7db97221ba502e3cb16803bf4f875319763b5050784->leave($__internal_552b0d32df3496339e82e7db97221ba502e3cb16803bf4f875319763b5050784_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_e60da36464e1b554090f4688e7d2c74cc898ba142681278762502a3f8ddc3a31 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e60da36464e1b554090f4688e7d2c74cc898ba142681278762502a3f8ddc3a31->enter($__internal_e60da36464e1b554090f4688e7d2c74cc898ba142681278762502a3f8ddc3a31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_be9c4362de215c504e07dca235eb351809c748a7d0ada96e628ce7280983a38c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_be9c4362de215c504e07dca235eb351809c748a7d0ada96e628ce7280983a38c->enter($__internal_be9c4362de215c504e07dca235eb351809c748a7d0ada96e628ce7280983a38c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 4, $this->getSourceContext()); })())) {
            // line 5
            echo "        <div>";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 5, $this->getSourceContext()); })()), "messageKey", array()), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new Twig_Error_Runtime('Variable "error" does not exist.', 5, $this->getSourceContext()); })()), "messageData", array()), "security"), "html", null, true);
            echo "</div>
    ";
        }
        // line 7
        echo "
    <form action=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("login");
        echo "\" method=\"post\">
        <label for=\"username\">Username:</label>
        <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 10
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new Twig_Error_Runtime('Variable "last_username" does not exist.', 10, $this->getSourceContext()); })()), "html", null, true);
        echo "\"/>

        <label for=\"password\">Password:</label>
        <input type=\"password\" id=\"password\" name=\"_password\" />


        <button type=\"submit\">login</button>
    </form>
";
        
        $__internal_be9c4362de215c504e07dca235eb351809c748a7d0ada96e628ce7280983a38c->leave($__internal_be9c4362de215c504e07dca235eb351809c748a7d0ada96e628ce7280983a38c_prof);

        
        $__internal_e60da36464e1b554090f4688e7d2c74cc898ba142681278762502a3f8ddc3a31->leave($__internal_e60da36464e1b554090f4688e7d2c74cc898ba142681278762502a3f8ddc3a31_prof);

    }

    public function getTemplateName()
    {
        return "login/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 10,  61 => 8,  58 => 7,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block body %}
    {% if error %}
        <div>{{ error.messageKey|trans(error.messageData, 'security') }}</div>
    {% endif %}

    <form action=\"{{path('login') }}\" method=\"post\">
        <label for=\"username\">Username:</label>
        <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\"/>

        <label for=\"password\">Password:</label>
        <input type=\"password\" id=\"password\" name=\"_password\" />


        <button type=\"submit\">login</button>
    </form>
{% endblock body %}", "login/login.html.twig", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\templates\\login\\login.html.twig");
    }
}
