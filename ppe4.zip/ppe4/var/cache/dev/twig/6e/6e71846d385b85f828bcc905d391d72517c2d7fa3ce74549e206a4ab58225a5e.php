<?php

/* @EasyAdmin/default/layout.html.twig */
class __TwigTemplate_7683896f333fb999459d129f04f436466d1e33aaad93712fdc43c0d1ab5ec7cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'page_title' => array($this, 'block_page_title'),
            'head_stylesheets' => array($this, 'block_head_stylesheets'),
            'head_favicon' => array($this, 'block_head_favicon'),
            'head_javascript' => array($this, 'block_head_javascript'),
            'adminlte_options' => array($this, 'block_adminlte_options'),
            'body' => array($this, 'block_body'),
            'body_id' => array($this, 'block_body_id'),
            'body_class' => array($this, 'block_body_class'),
            'wrapper' => array($this, 'block_wrapper'),
            'header' => array($this, 'block_header'),
            'header_logo' => array($this, 'block_header_logo'),
            'header_custom_menu' => array($this, 'block_header_custom_menu'),
            'user_menu' => array($this, 'block_user_menu'),
            'user_menu_dropdown' => array($this, 'block_user_menu_dropdown'),
            'sidebar' => array($this, 'block_sidebar'),
            'main_menu_wrapper' => array($this, 'block_main_menu_wrapper'),
            'content' => array($this, 'block_content'),
            'flash_messages' => array($this, 'block_flash_messages'),
            'content_header' => array($this, 'block_content_header'),
            'content_title' => array($this, 'block_content_title'),
            'content_help' => array($this, 'block_content_help'),
            'main' => array($this, 'block_main'),
            'body_javascript' => array($this, 'block_body_javascript'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63be115bb6130f33db260458546849d9c4852b45fc5c3a508a0620f6f7ee4b34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63be115bb6130f33db260458546849d9c4852b45fc5c3a508a0620f6f7ee4b34->enter($__internal_63be115bb6130f33db260458546849d9c4852b45fc5c3a508a0620f6f7ee4b34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@EasyAdmin/default/layout.html.twig"));

        $__internal_6ba127826c947650484968f014db5e32c21395e50d8181b67723cd014cd6bf00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ba127826c947650484968f014db5e32c21395e50d8181b67723cd014cd6bf00->enter($__internal_6ba127826c947650484968f014db5e32c21395e50d8181b67723cd014cd6bf00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@EasyAdmin/default/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, _twig_default_filter(twig_first($this->env, twig_split_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 2, $this->getSourceContext()); })()), "request", array()), "locale", array()), "_")), "en"), "html", null, true);
        echo "\">
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"robots\" content=\"noindex, nofollow, noarchive, nosnippet, noodp, noimageindex, notranslate, nocache\" />
        <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
        <meta name=\"generator\" content=\"EasyAdmin\" />

        <title>";
        // line 10
        $this->displayBlock('page_title', $context, $blocks);
        echo "</title>

        ";
        // line 12
        $this->displayBlock('head_stylesheets', $context, $blocks);
        // line 18
        echo "
        ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("design.assets.css"));
        foreach ($context['_seq'] as $context["_key"] => $context["css_asset"]) {
            // line 20
            echo "            <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($context["css_asset"]), "html", null, true);
            echo "\">
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['css_asset'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 22
        echo "
        ";
        // line 23
        $this->displayBlock('head_favicon', $context, $blocks);
        // line 27
        echo "
        ";
        // line 28
        $this->displayBlock('head_javascript', $context, $blocks);
        // line 45
        echo "
        ";
        // line 46
        if ($this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("design.rtl")) {
            // line 47
            echo "            <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/easyadmin/stylesheet/bootstrap-rtl.min.css"), "html", null, true);
            echo "\">
            <link rel=\"stylesheet\" href=\"";
            // line 48
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/easyadmin/stylesheet/adminlte-rtl.min.css"), "html", null, true);
            echo "\">
        ";
        }
        // line 50
        echo "    </head>

    ";
        // line 52
        $this->displayBlock('body', $context, $blocks);
        // line 162
        echo "</html>
";
        
        $__internal_63be115bb6130f33db260458546849d9c4852b45fc5c3a508a0620f6f7ee4b34->leave($__internal_63be115bb6130f33db260458546849d9c4852b45fc5c3a508a0620f6f7ee4b34_prof);

        
        $__internal_6ba127826c947650484968f014db5e32c21395e50d8181b67723cd014cd6bf00->leave($__internal_6ba127826c947650484968f014db5e32c21395e50d8181b67723cd014cd6bf00_prof);

    }

    // line 10
    public function block_page_title($context, array $blocks = array())
    {
        $__internal_548eb480704a5d29031ebf24a2ab5f9e120b647535fa8417a03133301caf6f85 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_548eb480704a5d29031ebf24a2ab5f9e120b647535fa8417a03133301caf6f85->enter($__internal_548eb480704a5d29031ebf24a2ab5f9e120b647535fa8417a03133301caf6f85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        $__internal_193e8d6dd4bce65d0486712c2cd677f17f06af44a5fcb6c79ef4ae731a4ed225 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_193e8d6dd4bce65d0486712c2cd677f17f06af44a5fcb6c79ef4ae731a4ed225->enter($__internal_193e8d6dd4bce65d0486712c2cd677f17f06af44a5fcb6c79ef4ae731a4ed225_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "page_title"));

        echo strip_tags(        $this->renderBlock("content_title", $context, $blocks));
        
        $__internal_193e8d6dd4bce65d0486712c2cd677f17f06af44a5fcb6c79ef4ae731a4ed225->leave($__internal_193e8d6dd4bce65d0486712c2cd677f17f06af44a5fcb6c79ef4ae731a4ed225_prof);

        
        $__internal_548eb480704a5d29031ebf24a2ab5f9e120b647535fa8417a03133301caf6f85->leave($__internal_548eb480704a5d29031ebf24a2ab5f9e120b647535fa8417a03133301caf6f85_prof);

    }

    // line 12
    public function block_head_stylesheets($context, array $blocks = array())
    {
        $__internal_795392b7976f03e7f528c0f6b7dab12f81d6c8d59bf573ce086f44f48a9b5c59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_795392b7976f03e7f528c0f6b7dab12f81d6c8d59bf573ce086f44f48a9b5c59->enter($__internal_795392b7976f03e7f528c0f6b7dab12f81d6c8d59bf573ce086f44f48a9b5c59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_stylesheets"));

        $__internal_f4255aee3532535dd461e84d2c59623b383070b1c548afac515eb22d227f6483 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4255aee3532535dd461e84d2c59623b383070b1c548afac515eb22d227f6483->enter($__internal_f4255aee3532535dd461e84d2c59623b383070b1c548afac515eb22d227f6483_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_stylesheets"));

        // line 13
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/easyadmin/stylesheet/easyadmin-all.min.css"), "html", null, true);
        echo "\">
            <style>
                ";
        // line 15
        echo $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("_internal.custom_css");
        echo "
            </style>
        ";
        
        $__internal_f4255aee3532535dd461e84d2c59623b383070b1c548afac515eb22d227f6483->leave($__internal_f4255aee3532535dd461e84d2c59623b383070b1c548afac515eb22d227f6483_prof);

        
        $__internal_795392b7976f03e7f528c0f6b7dab12f81d6c8d59bf573ce086f44f48a9b5c59->leave($__internal_795392b7976f03e7f528c0f6b7dab12f81d6c8d59bf573ce086f44f48a9b5c59_prof);

    }

    // line 23
    public function block_head_favicon($context, array $blocks = array())
    {
        $__internal_097e74ad9f31609ffd1eadad1e7e5c41f101bdbb83c6ffda961de9c2b80373df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_097e74ad9f31609ffd1eadad1e7e5c41f101bdbb83c6ffda961de9c2b80373df->enter($__internal_097e74ad9f31609ffd1eadad1e7e5c41f101bdbb83c6ffda961de9c2b80373df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_favicon"));

        $__internal_a39dd51479812500251bd9796f9a2d83f791aabaa87f6e5d261a1dffc4d61e49 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a39dd51479812500251bd9796f9a2d83f791aabaa87f6e5d261a1dffc4d61e49->enter($__internal_a39dd51479812500251bd9796f9a2d83f791aabaa87f6e5d261a1dffc4d61e49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_favicon"));

        // line 24
        echo "            ";
        $context["favicon"] = $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("design.assets.favicon");
        // line 25
        echo "            <link rel=\"icon\" type=\"";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["favicon"]) || array_key_exists("favicon", $context) ? $context["favicon"] : (function () { throw new Twig_Error_Runtime('Variable "favicon" does not exist.', 25, $this->getSourceContext()); })()), "mime_type", array()), "html", null, true);
        echo "\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["favicon"]) || array_key_exists("favicon", $context) ? $context["favicon"] : (function () { throw new Twig_Error_Runtime('Variable "favicon" does not exist.', 25, $this->getSourceContext()); })()), "path", array())), "html", null, true);
        echo "\" />
        ";
        
        $__internal_a39dd51479812500251bd9796f9a2d83f791aabaa87f6e5d261a1dffc4d61e49->leave($__internal_a39dd51479812500251bd9796f9a2d83f791aabaa87f6e5d261a1dffc4d61e49_prof);

        
        $__internal_097e74ad9f31609ffd1eadad1e7e5c41f101bdbb83c6ffda961de9c2b80373df->leave($__internal_097e74ad9f31609ffd1eadad1e7e5c41f101bdbb83c6ffda961de9c2b80373df_prof);

    }

    // line 28
    public function block_head_javascript($context, array $blocks = array())
    {
        $__internal_95685440f6591755b089bd9e6d46edd44a817f8880d6cd0dc2751bcfb6fa76e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95685440f6591755b089bd9e6d46edd44a817f8880d6cd0dc2751bcfb6fa76e3->enter($__internal_95685440f6591755b089bd9e6d46edd44a817f8880d6cd0dc2751bcfb6fa76e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_javascript"));

        $__internal_b273a9eef7ab10ff23d8b715d510f4016289fe3031e398957f24da194f56e011 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b273a9eef7ab10ff23d8b715d510f4016289fe3031e398957f24da194f56e011->enter($__internal_b273a9eef7ab10ff23d8b715d510f4016289fe3031e398957f24da194f56e011_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head_javascript"));

        // line 29
        echo "            ";
        $this->displayBlock('adminlte_options', $context, $blocks);
        // line 42
        echo "
            <script src=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/easyadmin/javascript/easyadmin-all.min.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_b273a9eef7ab10ff23d8b715d510f4016289fe3031e398957f24da194f56e011->leave($__internal_b273a9eef7ab10ff23d8b715d510f4016289fe3031e398957f24da194f56e011_prof);

        
        $__internal_95685440f6591755b089bd9e6d46edd44a817f8880d6cd0dc2751bcfb6fa76e3->leave($__internal_95685440f6591755b089bd9e6d46edd44a817f8880d6cd0dc2751bcfb6fa76e3_prof);

    }

    // line 29
    public function block_adminlte_options($context, array $blocks = array())
    {
        $__internal_87c2cd3b3e82efce306ee5aaf8465d112a929de9688ba48398ea803285677fe0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87c2cd3b3e82efce306ee5aaf8465d112a929de9688ba48398ea803285677fe0->enter($__internal_87c2cd3b3e82efce306ee5aaf8465d112a929de9688ba48398ea803285677fe0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "adminlte_options"));

        $__internal_cfb028887d5b546131e17f6c2ed955e896bc1506d9183e93da424c93724b9917 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cfb028887d5b546131e17f6c2ed955e896bc1506d9183e93da424c93724b9917->enter($__internal_cfb028887d5b546131e17f6c2ed955e896bc1506d9183e93da424c93724b9917_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "adminlte_options"));

        // line 30
        echo "                <script type=\"text/javascript\">
                    var AdminLTEOptions = {
                        animationSpeed: 'normal',
                        sidebarExpandOnHover: false,
                        enableBoxRefresh: false,
                        enableBSToppltip: false,
                        enableFastclick: false,
                        enableControlSidebar: false,
                        enableBoxWidget: false
                    };
                </script>
            ";
        
        $__internal_cfb028887d5b546131e17f6c2ed955e896bc1506d9183e93da424c93724b9917->leave($__internal_cfb028887d5b546131e17f6c2ed955e896bc1506d9183e93da424c93724b9917_prof);

        
        $__internal_87c2cd3b3e82efce306ee5aaf8465d112a929de9688ba48398ea803285677fe0->leave($__internal_87c2cd3b3e82efce306ee5aaf8465d112a929de9688ba48398ea803285677fe0_prof);

    }

    // line 52
    public function block_body($context, array $blocks = array())
    {
        $__internal_35c0850375f3bd50bffbce31f86f5c74ddc5fb453c9eea00cc3fbb4a3e06cd88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_35c0850375f3bd50bffbce31f86f5c74ddc5fb453c9eea00cc3fbb4a3e06cd88->enter($__internal_35c0850375f3bd50bffbce31f86f5c74ddc5fb453c9eea00cc3fbb4a3e06cd88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d57167f9e52fea9c7e6cbbbe3a56b9cbf9ff32218fb469b66a682ae2255cb22b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d57167f9e52fea9c7e6cbbbe3a56b9cbf9ff32218fb469b66a682ae2255cb22b->enter($__internal_d57167f9e52fea9c7e6cbbbe3a56b9cbf9ff32218fb469b66a682ae2255cb22b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 53
        echo "    <body id=\"";
        $this->displayBlock('body_id', $context, $blocks);
        echo "\" class=\"easyadmin sidebar-mini ";
        $this->displayBlock('body_class', $context, $blocks);
        echo " ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 53, $this->getSourceContext()); })()), "request", array()), "cookies", array()), "has", array(0 => "_easyadmin_navigation_iscollapsed"), "method")) ? ("sidebar-collapse") : (""));
        echo "\">
        <div class=\"wrapper\">
        ";
        // line 55
        $this->displayBlock('wrapper', $context, $blocks);
        // line 153
        echo "        </div>

        ";
        // line 155
        $this->displayBlock('body_javascript', $context, $blocks);
        // line 156
        echo "
        ";
        // line 157
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("design.assets.js"));
        foreach ($context['_seq'] as $context["_key"] => $context["js_asset"]) {
            // line 158
            echo "            <script src=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl($context["js_asset"]), "html", null, true);
            echo "\"></script>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['js_asset'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 160
        echo "    </body>
    ";
        
        $__internal_d57167f9e52fea9c7e6cbbbe3a56b9cbf9ff32218fb469b66a682ae2255cb22b->leave($__internal_d57167f9e52fea9c7e6cbbbe3a56b9cbf9ff32218fb469b66a682ae2255cb22b_prof);

        
        $__internal_35c0850375f3bd50bffbce31f86f5c74ddc5fb453c9eea00cc3fbb4a3e06cd88->leave($__internal_35c0850375f3bd50bffbce31f86f5c74ddc5fb453c9eea00cc3fbb4a3e06cd88_prof);

    }

    // line 53
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_2942285cfda5c2c9b4a7067ed7f12b5dc40be467f40d7e4eb93546631f99fe5d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2942285cfda5c2c9b4a7067ed7f12b5dc40be467f40d7e4eb93546631f99fe5d->enter($__internal_2942285cfda5c2c9b4a7067ed7f12b5dc40be467f40d7e4eb93546631f99fe5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_5537ecc568f08766188b91b913a1ce78ef90b2d72adff70a2a9c999dfd3add8a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5537ecc568f08766188b91b913a1ce78ef90b2d72adff70a2a9c999dfd3add8a->enter($__internal_5537ecc568f08766188b91b913a1ce78ef90b2d72adff70a2a9c999dfd3add8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_5537ecc568f08766188b91b913a1ce78ef90b2d72adff70a2a9c999dfd3add8a->leave($__internal_5537ecc568f08766188b91b913a1ce78ef90b2d72adff70a2a9c999dfd3add8a_prof);

        
        $__internal_2942285cfda5c2c9b4a7067ed7f12b5dc40be467f40d7e4eb93546631f99fe5d->leave($__internal_2942285cfda5c2c9b4a7067ed7f12b5dc40be467f40d7e4eb93546631f99fe5d_prof);

    }

    public function block_body_class($context, array $blocks = array())
    {
        $__internal_972e3812ca839fc4e1cc5ede056294e9e321d82eda1495295acefbce634dae91 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_972e3812ca839fc4e1cc5ede056294e9e321d82eda1495295acefbce634dae91->enter($__internal_972e3812ca839fc4e1cc5ede056294e9e321d82eda1495295acefbce634dae91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_class"));

        $__internal_391c724df8582706f7e897c573e24657f30106bc8fe8369ed5271f6a5730d3e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_391c724df8582706f7e897c573e24657f30106bc8fe8369ed5271f6a5730d3e0->enter($__internal_391c724df8582706f7e897c573e24657f30106bc8fe8369ed5271f6a5730d3e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_class"));

        
        $__internal_391c724df8582706f7e897c573e24657f30106bc8fe8369ed5271f6a5730d3e0->leave($__internal_391c724df8582706f7e897c573e24657f30106bc8fe8369ed5271f6a5730d3e0_prof);

        
        $__internal_972e3812ca839fc4e1cc5ede056294e9e321d82eda1495295acefbce634dae91->leave($__internal_972e3812ca839fc4e1cc5ede056294e9e321d82eda1495295acefbce634dae91_prof);

    }

    // line 55
    public function block_wrapper($context, array $blocks = array())
    {
        $__internal_fe12a33322437cb188d20a5d0d344466948675b737c28352bde8ff6f9c842dd8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fe12a33322437cb188d20a5d0d344466948675b737c28352bde8ff6f9c842dd8->enter($__internal_fe12a33322437cb188d20a5d0d344466948675b737c28352bde8ff6f9c842dd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "wrapper"));

        $__internal_f1db2625de259d65ce9c5378eb10b1bf353d19aa3148b0a97f4a466e74966559 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f1db2625de259d65ce9c5378eb10b1bf353d19aa3148b0a97f4a466e74966559->enter($__internal_f1db2625de259d65ce9c5378eb10b1bf353d19aa3148b0a97f4a466e74966559_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "wrapper"));

        // line 56
        echo "            <header class=\"main-header\">
            ";
        // line 57
        $this->displayBlock('header', $context, $blocks);
        // line 110
        echo "            </header>

            <aside class=\"main-sidebar\">
            ";
        // line 113
        $this->displayBlock('sidebar', $context, $blocks);
        // line 124
        echo "            </aside>

            <div class=\"content-wrapper\">
            ";
        // line 127
        $this->displayBlock('content', $context, $blocks);
        // line 151
        echo "            </div>
        ";
        
        $__internal_f1db2625de259d65ce9c5378eb10b1bf353d19aa3148b0a97f4a466e74966559->leave($__internal_f1db2625de259d65ce9c5378eb10b1bf353d19aa3148b0a97f4a466e74966559_prof);

        
        $__internal_fe12a33322437cb188d20a5d0d344466948675b737c28352bde8ff6f9c842dd8->leave($__internal_fe12a33322437cb188d20a5d0d344466948675b737c28352bde8ff6f9c842dd8_prof);

    }

    // line 57
    public function block_header($context, array $blocks = array())
    {
        $__internal_c6bfbac5f3767f8d859b080b0f2254b14e04ff62f48511ebd006a83e2416044e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6bfbac5f3767f8d859b080b0f2254b14e04ff62f48511ebd006a83e2416044e->enter($__internal_c6bfbac5f3767f8d859b080b0f2254b14e04ff62f48511ebd006a83e2416044e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_5fa24dab1f33b46fa06057c6d56b687ed8ae77311f758920a9a9411c59ec96e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5fa24dab1f33b46fa06057c6d56b687ed8ae77311f758920a9a9411c59ec96e6->enter($__internal_5fa24dab1f33b46fa06057c6d56b687ed8ae77311f758920a9a9411c59ec96e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 58
        echo "                <nav class=\"navbar\" role=\"navigation\">
                    <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                        <span class=\"sr-only\">";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("toggle_navigation", array(), "EasyAdminBundle"), "html", null, true);
        echo "</span>
                    </a>

                    <div id=\"header-logo\">
                        ";
        // line 64
        $this->displayBlock('header_logo', $context, $blocks);
        // line 69
        echo "                    </div>

                    <div class=\"navbar-custom-menu\">
                    ";
        // line 72
        $this->displayBlock('header_custom_menu', $context, $blocks);
        // line 107
        echo "                    </div>
                </nav>
            ";
        
        $__internal_5fa24dab1f33b46fa06057c6d56b687ed8ae77311f758920a9a9411c59ec96e6->leave($__internal_5fa24dab1f33b46fa06057c6d56b687ed8ae77311f758920a9a9411c59ec96e6_prof);

        
        $__internal_c6bfbac5f3767f8d859b080b0f2254b14e04ff62f48511ebd006a83e2416044e->leave($__internal_c6bfbac5f3767f8d859b080b0f2254b14e04ff62f48511ebd006a83e2416044e_prof);

    }

    // line 64
    public function block_header_logo($context, array $blocks = array())
    {
        $__internal_ee5368099c0df6be784fb3ffe87f9b807c6b423406ff646f9950587b6e3cadfb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee5368099c0df6be784fb3ffe87f9b807c6b423406ff646f9950587b6e3cadfb->enter($__internal_ee5368099c0df6be784fb3ffe87f9b807c6b423406ff646f9950587b6e3cadfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_logo"));

        $__internal_a5adb5cf9692943a927c7e0f07839bec09710fe4a9ee74ab02ba02c2c98d55d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a5adb5cf9692943a927c7e0f07839bec09710fe4a9ee74ab02ba02c2c98d55d7->enter($__internal_a5adb5cf9692943a927c7e0f07839bec09710fe4a9ee74ab02ba02c2c98d55d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_logo"));

        // line 65
        echo "                            <a class=\"logo ";
        echo (((twig_length_filter($this->env, $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("site_name")) > 14)) ? ("logo-long") : (""));
        echo "\" title=\"";
        echo twig_escape_filter($this->env, strip_tags($this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("site_name")), "html", null, true);
        echo "\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("easyadmin");
        echo "\">
                                ";
        // line 66
        echo $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("site_name");
        echo "
                            </a>
                        ";
        
        $__internal_a5adb5cf9692943a927c7e0f07839bec09710fe4a9ee74ab02ba02c2c98d55d7->leave($__internal_a5adb5cf9692943a927c7e0f07839bec09710fe4a9ee74ab02ba02c2c98d55d7_prof);

        
        $__internal_ee5368099c0df6be784fb3ffe87f9b807c6b423406ff646f9950587b6e3cadfb->leave($__internal_ee5368099c0df6be784fb3ffe87f9b807c6b423406ff646f9950587b6e3cadfb_prof);

    }

    // line 72
    public function block_header_custom_menu($context, array $blocks = array())
    {
        $__internal_6a83fecfd0567bb2b8bb6bf25f6e813a21b955ba900efd983b1b736e49a4f59d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6a83fecfd0567bb2b8bb6bf25f6e813a21b955ba900efd983b1b736e49a4f59d->enter($__internal_6a83fecfd0567bb2b8bb6bf25f6e813a21b955ba900efd983b1b736e49a4f59d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_custom_menu"));

        $__internal_b1e6fdecc556ae86bc2962c96a7e0110c054dbf4709a0daa1b935cdb69b338a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b1e6fdecc556ae86bc2962c96a7e0110c054dbf4709a0daa1b935cdb69b338a9->enter($__internal_b1e6fdecc556ae86bc2962c96a7e0110c054dbf4709a0daa1b935cdb69b338a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_custom_menu"));

        // line 73
        echo "                        ";
        $context["_logout_path"] = $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getLogoutPath();
        // line 74
        echo "                        <ul class=\"nav navbar-nav\">
                            <li class=\"dropdown user user-menu\">
                                ";
        // line 76
        $this->displayBlock('user_menu', $context, $blocks);
        // line 104
        echo "                            </li>
                        </ul>
                    ";
        
        $__internal_b1e6fdecc556ae86bc2962c96a7e0110c054dbf4709a0daa1b935cdb69b338a9->leave($__internal_b1e6fdecc556ae86bc2962c96a7e0110c054dbf4709a0daa1b935cdb69b338a9_prof);

        
        $__internal_6a83fecfd0567bb2b8bb6bf25f6e813a21b955ba900efd983b1b736e49a4f59d->leave($__internal_6a83fecfd0567bb2b8bb6bf25f6e813a21b955ba900efd983b1b736e49a4f59d_prof);

    }

    // line 76
    public function block_user_menu($context, array $blocks = array())
    {
        $__internal_cb643dadc1d8e0deebdcf295cbf3e6262759667724f9bf8c13652ba25c881210 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb643dadc1d8e0deebdcf295cbf3e6262759667724f9bf8c13652ba25c881210->enter($__internal_cb643dadc1d8e0deebdcf295cbf3e6262759667724f9bf8c13652ba25c881210_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "user_menu"));

        $__internal_15ed917999f8ae34844c1df1fc5e728cbf2ba7ab3258bf672b8be9243bd62466 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15ed917999f8ae34844c1df1fc5e728cbf2ba7ab3258bf672b8be9243bd62466->enter($__internal_15ed917999f8ae34844c1df1fc5e728cbf2ba7ab3258bf672b8be9243bd62466_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "user_menu"));

        // line 77
        echo "                                    <span class=\"sr-only\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.logged_in_as", array(), "EasyAdminBundle"), "html", null, true);
        echo "</span>

                                    ";
        // line 79
        if ((((twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "user", array(), "any", true, true)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "user", array()), false)) : (false)) == false)) {
            // line 80
            echo "                                        <i class=\"hidden-xs fa fa-user-times\"></i>
                                        ";
            // line 81
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.anonymous", array(), "EasyAdminBundle"), "html", null, true);
            echo "
                                    ";
        } elseif ( !        // line 82
(isset($context["_logout_path"]) || array_key_exists("_logout_path", $context) ? $context["_logout_path"] : (function () { throw new Twig_Error_Runtime('Variable "_logout_path" does not exist.', 82, $this->getSourceContext()); })())) {
            // line 83
            echo "                                        <i class=\"hidden-xs fa fa-user\"></i>
                                        ";
            // line 84
            echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "user", array(), "any", false, true), "username", array(), "any", true, true)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "user", array(), "any", false, true), "username", array()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.unnamed", array(), "EasyAdminBundle"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.unnamed", array(), "EasyAdminBundle"))), "html", null, true);
            echo "
                                    ";
        } else {
            // line 86
            echo "                                        <div class=\"btn-group\">
                                            <button type=\"button\" class=\"btn\" data-toggle=\"dropdown\">
                                                <i class=\"hidden-xs fa fa-user\"></i>
                                                ";
            // line 89
            echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "user", array(), "any", false, true), "username", array(), "any", true, true)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["app"] ?? null), "user", array(), "any", false, true), "username", array()), $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.unnamed", array(), "EasyAdminBundle"))) : ($this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.unnamed", array(), "EasyAdminBundle"))), "html", null, true);
            echo "
                                            </button>
                                            <button type=\"button\" class=\"btn dropdown-toggle\" data-toggle=\"dropdown\" aria-expanded=\"false\">
                                                <span class=\"caret\"></span>
                                            </button>
                                            <ul class=\"dropdown-menu\" role=\"menu\">
                                                ";
            // line 95
            $this->displayBlock('user_menu_dropdown', $context, $blocks);
            // line 100
            echo "                                            </ul>
                                        </div>
                                    ";
        }
        // line 103
        echo "                                ";
        
        $__internal_15ed917999f8ae34844c1df1fc5e728cbf2ba7ab3258bf672b8be9243bd62466->leave($__internal_15ed917999f8ae34844c1df1fc5e728cbf2ba7ab3258bf672b8be9243bd62466_prof);

        
        $__internal_cb643dadc1d8e0deebdcf295cbf3e6262759667724f9bf8c13652ba25c881210->leave($__internal_cb643dadc1d8e0deebdcf295cbf3e6262759667724f9bf8c13652ba25c881210_prof);

    }

    // line 95
    public function block_user_menu_dropdown($context, array $blocks = array())
    {
        $__internal_d6a6a51661e208faffbcecf8f2ad4c3c3247badfd535e653f034d672f3454195 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6a6a51661e208faffbcecf8f2ad4c3c3247badfd535e653f034d672f3454195->enter($__internal_d6a6a51661e208faffbcecf8f2ad4c3c3247badfd535e653f034d672f3454195_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "user_menu_dropdown"));

        $__internal_88ea574eb0ae2f766b93d0bf30640f634b16f40f803c514a0268d2b5a3c8f606 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_88ea574eb0ae2f766b93d0bf30640f634b16f40f803c514a0268d2b5a3c8f606->enter($__internal_88ea574eb0ae2f766b93d0bf30640f634b16f40f803c514a0268d2b5a3c8f606_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "user_menu_dropdown"));

        // line 96
        echo "                                                <li>
                                                    <a href=\"";
        // line 97
        echo twig_escape_filter($this->env, (isset($context["_logout_path"]) || array_key_exists("_logout_path", $context) ? $context["_logout_path"] : (function () { throw new Twig_Error_Runtime('Variable "_logout_path" does not exist.', 97, $this->getSourceContext()); })()), "html", null, true);
        echo "\"><i class=\"fa fa-sign-out\"></i> ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("user.signout", array(), "EasyAdminBundle"), "html", null, true);
        echo "</a>
                                                </li>
                                                ";
        
        $__internal_88ea574eb0ae2f766b93d0bf30640f634b16f40f803c514a0268d2b5a3c8f606->leave($__internal_88ea574eb0ae2f766b93d0bf30640f634b16f40f803c514a0268d2b5a3c8f606_prof);

        
        $__internal_d6a6a51661e208faffbcecf8f2ad4c3c3247badfd535e653f034d672f3454195->leave($__internal_d6a6a51661e208faffbcecf8f2ad4c3c3247badfd535e653f034d672f3454195_prof);

    }

    // line 113
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_656ffe0511ae71146feb7e2a63a11e9734c5c35950d06652dd0e057c995a9fbe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_656ffe0511ae71146feb7e2a63a11e9734c5c35950d06652dd0e057c995a9fbe->enter($__internal_656ffe0511ae71146feb7e2a63a11e9734c5c35950d06652dd0e057c995a9fbe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_29445cc1c142b2a358046a0ce52eb03ed0fe40e9f76aef878c116e4f75e64863 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_29445cc1c142b2a358046a0ce52eb03ed0fe40e9f76aef878c116e4f75e64863->enter($__internal_29445cc1c142b2a358046a0ce52eb03ed0fe40e9f76aef878c116e4f75e64863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 114
        echo "                <section class=\"sidebar\">
                    ";
        // line 115
        $this->displayBlock('main_menu_wrapper', $context, $blocks);
        // line 122
        echo "                </section>
            ";
        
        $__internal_29445cc1c142b2a358046a0ce52eb03ed0fe40e9f76aef878c116e4f75e64863->leave($__internal_29445cc1c142b2a358046a0ce52eb03ed0fe40e9f76aef878c116e4f75e64863_prof);

        
        $__internal_656ffe0511ae71146feb7e2a63a11e9734c5c35950d06652dd0e057c995a9fbe->leave($__internal_656ffe0511ae71146feb7e2a63a11e9734c5c35950d06652dd0e057c995a9fbe_prof);

    }

    // line 115
    public function block_main_menu_wrapper($context, array $blocks = array())
    {
        $__internal_8e140d4daf20f38b75f45c1fea4b657635fdf4eac36e3d58bf047a2dca43e8a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e140d4daf20f38b75f45c1fea4b657635fdf4eac36e3d58bf047a2dca43e8a2->enter($__internal_8e140d4daf20f38b75f45c1fea4b657635fdf4eac36e3d58bf047a2dca43e8a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_menu_wrapper"));

        $__internal_a128a7706dee4204d3082ee7e92693551c13988d5c7be8d998297dabf7cc8c3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a128a7706dee4204d3082ee7e92693551c13988d5c7be8d998297dabf7cc8c3c->enter($__internal_a128a7706dee4204d3082ee7e92693551c13988d5c7be8d998297dabf7cc8c3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main_menu_wrapper"));

        // line 116
        echo "                        ";
        echo twig_include($this->env, $context, array(0 => ((        // line 117
array_key_exists("_entity_config", $context)) ? (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["_entity_config"]) || array_key_exists("_entity_config", $context) ? $context["_entity_config"] : (function () { throw new Twig_Error_Runtime('Variable "_entity_config" does not exist.', 117, $this->getSourceContext()); })()), "templates", array()), "menu", array())) : ("")), 1 => $this->env->getExtension('EasyCorp\Bundle\EasyAdminBundle\Twig\EasyAdminTwigExtension')->getBackendConfiguration("design.templates.menu"), 2 => "@EasyAdmin/default/menu.html.twig"));
        // line 120
        echo "
                    ";
        
        $__internal_a128a7706dee4204d3082ee7e92693551c13988d5c7be8d998297dabf7cc8c3c->leave($__internal_a128a7706dee4204d3082ee7e92693551c13988d5c7be8d998297dabf7cc8c3c_prof);

        
        $__internal_8e140d4daf20f38b75f45c1fea4b657635fdf4eac36e3d58bf047a2dca43e8a2->leave($__internal_8e140d4daf20f38b75f45c1fea4b657635fdf4eac36e3d58bf047a2dca43e8a2_prof);

    }

    // line 127
    public function block_content($context, array $blocks = array())
    {
        $__internal_e903d9842dec0eead4cdce6e1e751f4c04bea1d12bb2c37dadcec7d3fbca11ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e903d9842dec0eead4cdce6e1e751f4c04bea1d12bb2c37dadcec7d3fbca11ea->enter($__internal_e903d9842dec0eead4cdce6e1e751f4c04bea1d12bb2c37dadcec7d3fbca11ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        $__internal_c6d25c2fb309711da3a1d1f0962c81c61afcf9bb85f4ed85fe669bb177d184da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c6d25c2fb309711da3a1d1f0962c81c61afcf9bb85f4ed85fe669bb177d184da->enter($__internal_c6d25c2fb309711da3a1d1f0962c81c61afcf9bb85f4ed85fe669bb177d184da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 128
        echo "                ";
        $this->displayBlock('flash_messages', $context, $blocks);
        // line 131
        echo "
                <section class=\"content-header\">
                ";
        // line 133
        $this->displayBlock('content_header', $context, $blocks);
        // line 136
        echo "                ";
        $this->displayBlock('content_help', $context, $blocks);
        // line 145
        echo "                </section>

                <section id=\"main\" class=\"content\">
                    ";
        // line 148
        $this->displayBlock('main', $context, $blocks);
        // line 149
        echo "                </section>
            ";
        
        $__internal_c6d25c2fb309711da3a1d1f0962c81c61afcf9bb85f4ed85fe669bb177d184da->leave($__internal_c6d25c2fb309711da3a1d1f0962c81c61afcf9bb85f4ed85fe669bb177d184da_prof);

        
        $__internal_e903d9842dec0eead4cdce6e1e751f4c04bea1d12bb2c37dadcec7d3fbca11ea->leave($__internal_e903d9842dec0eead4cdce6e1e751f4c04bea1d12bb2c37dadcec7d3fbca11ea_prof);

    }

    // line 128
    public function block_flash_messages($context, array $blocks = array())
    {
        $__internal_f8630440c99d12e5cd10a24be5ecc7ec962b4cdb008de49d8f03fd3a6df21199 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8630440c99d12e5cd10a24be5ecc7ec962b4cdb008de49d8f03fd3a6df21199->enter($__internal_f8630440c99d12e5cd10a24be5ecc7ec962b4cdb008de49d8f03fd3a6df21199_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flash_messages"));

        $__internal_1989e7a238ed45bc724d982e697dbc16b3d739a7b92cfbf565b87590e2b2843b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1989e7a238ed45bc724d982e697dbc16b3d739a7b92cfbf565b87590e2b2843b->enter($__internal_1989e7a238ed45bc724d982e697dbc16b3d739a7b92cfbf565b87590e2b2843b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "flash_messages"));

        // line 129
        echo "                    ";
        echo twig_include($this->env, $context, ((array_key_exists("_entity_config", $context)) ? (twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["_entity_config"]) || array_key_exists("_entity_config", $context) ? $context["_entity_config"] : (function () { throw new Twig_Error_Runtime('Variable "_entity_config" does not exist.', 129, $this->getSourceContext()); })()), "templates", array()), "flash_messages", array())) : ("@EasyAdmin/default/flash_messages.html.twig")));
        echo "
                ";
        
        $__internal_1989e7a238ed45bc724d982e697dbc16b3d739a7b92cfbf565b87590e2b2843b->leave($__internal_1989e7a238ed45bc724d982e697dbc16b3d739a7b92cfbf565b87590e2b2843b_prof);

        
        $__internal_f8630440c99d12e5cd10a24be5ecc7ec962b4cdb008de49d8f03fd3a6df21199->leave($__internal_f8630440c99d12e5cd10a24be5ecc7ec962b4cdb008de49d8f03fd3a6df21199_prof);

    }

    // line 133
    public function block_content_header($context, array $blocks = array())
    {
        $__internal_56db1ecb798f3b4d9e759a5140775998022a77387984bb757e6d9ec11f598fc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56db1ecb798f3b4d9e759a5140775998022a77387984bb757e6d9ec11f598fc0->enter($__internal_56db1ecb798f3b4d9e759a5140775998022a77387984bb757e6d9ec11f598fc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_header"));

        $__internal_b180f71f1f9be2927c183f64e071cf7225bcfd30b9f0ae6303309fab831c93a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b180f71f1f9be2927c183f64e071cf7225bcfd30b9f0ae6303309fab831c93a2->enter($__internal_b180f71f1f9be2927c183f64e071cf7225bcfd30b9f0ae6303309fab831c93a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_header"));

        // line 134
        echo "                    <h1 class=\"title\">";
        $this->displayBlock('content_title', $context, $blocks);
        echo "</h1>
                ";
        
        $__internal_b180f71f1f9be2927c183f64e071cf7225bcfd30b9f0ae6303309fab831c93a2->leave($__internal_b180f71f1f9be2927c183f64e071cf7225bcfd30b9f0ae6303309fab831c93a2_prof);

        
        $__internal_56db1ecb798f3b4d9e759a5140775998022a77387984bb757e6d9ec11f598fc0->leave($__internal_56db1ecb798f3b4d9e759a5140775998022a77387984bb757e6d9ec11f598fc0_prof);

    }

    public function block_content_title($context, array $blocks = array())
    {
        $__internal_3053dde739f672306604e900c25fdd0dc5a8612fb258bd744e2804c9474f23f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3053dde739f672306604e900c25fdd0dc5a8612fb258bd744e2804c9474f23f9->enter($__internal_3053dde739f672306604e900c25fdd0dc5a8612fb258bd744e2804c9474f23f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_title"));

        $__internal_38fe48d7289add7340d260744b6cae41071ccb47b0aef5f1ae155bf88dbdad9b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38fe48d7289add7340d260744b6cae41071ccb47b0aef5f1ae155bf88dbdad9b->enter($__internal_38fe48d7289add7340d260744b6cae41071ccb47b0aef5f1ae155bf88dbdad9b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_title"));

        
        $__internal_38fe48d7289add7340d260744b6cae41071ccb47b0aef5f1ae155bf88dbdad9b->leave($__internal_38fe48d7289add7340d260744b6cae41071ccb47b0aef5f1ae155bf88dbdad9b_prof);

        
        $__internal_3053dde739f672306604e900c25fdd0dc5a8612fb258bd744e2804c9474f23f9->leave($__internal_3053dde739f672306604e900c25fdd0dc5a8612fb258bd744e2804c9474f23f9_prof);

    }

    // line 136
    public function block_content_help($context, array $blocks = array())
    {
        $__internal_517884d5424d48199db3580e2bee3ccd0f250fe77b77bad862e3cd25067de28a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_517884d5424d48199db3580e2bee3ccd0f250fe77b77bad862e3cd25067de28a->enter($__internal_517884d5424d48199db3580e2bee3ccd0f250fe77b77bad862e3cd25067de28a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_help"));

        $__internal_98f7ac058d8423e2bf40907b90c4d7bc39f72b2f2b4c1c809f3a40cf12c8b6db = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98f7ac058d8423e2bf40907b90c4d7bc39f72b2f2b4c1c809f3a40cf12c8b6db->enter($__internal_98f7ac058d8423e2bf40907b90c4d7bc39f72b2f2b4c1c809f3a40cf12c8b6db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content_help"));

        // line 137
        echo "                    ";
        if ((array_key_exists("_entity_config", $context) && ((twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["_entity_config"] ?? null), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 137, $this->getSourceContext()); })()), "request", array()), "query", array()), "get", array(0 => "action"), "method"), array(), "array", false, true), "help", array(), "array", true, true)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), ($context["_entity_config"] ?? null), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 137, $this->getSourceContext()); })()), "request", array()), "query", array()), "get", array(0 => "action"), "method"), array(), "array", false, true), "help", array(), "array"), false)) : (false)))) {
            // line 138
            echo "                        <div class=\"box box-widget help-entity\">
                            <div class=\"box-body\">
                                ";
            // line 140
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans(twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["_entity_config"]) || array_key_exists("_entity_config", $context) ? $context["_entity_config"] : (function () { throw new Twig_Error_Runtime('Variable "_entity_config" does not exist.', 140, $this->getSourceContext()); })()), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 140, $this->getSourceContext()); })()), "request", array()), "query", array()), "get", array(0 => "action"), "method"), array(), "array"), "help", array(), "array"));
            echo "
                            </div>
                        </div>
                    ";
        }
        // line 144
        echo "                ";
        
        $__internal_98f7ac058d8423e2bf40907b90c4d7bc39f72b2f2b4c1c809f3a40cf12c8b6db->leave($__internal_98f7ac058d8423e2bf40907b90c4d7bc39f72b2f2b4c1c809f3a40cf12c8b6db_prof);

        
        $__internal_517884d5424d48199db3580e2bee3ccd0f250fe77b77bad862e3cd25067de28a->leave($__internal_517884d5424d48199db3580e2bee3ccd0f250fe77b77bad862e3cd25067de28a_prof);

    }

    // line 148
    public function block_main($context, array $blocks = array())
    {
        $__internal_433807ae3c4c42ac87c34eaac32570356e8abc1f83e55cf6806c92f45cade17d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_433807ae3c4c42ac87c34eaac32570356e8abc1f83e55cf6806c92f45cade17d->enter($__internal_433807ae3c4c42ac87c34eaac32570356e8abc1f83e55cf6806c92f45cade17d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_e8eb65f3ddc97fe0630929832361c19979b6dfa6b64a66bf2d1ceb49063de663 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8eb65f3ddc97fe0630929832361c19979b6dfa6b64a66bf2d1ceb49063de663->enter($__internal_e8eb65f3ddc97fe0630929832361c19979b6dfa6b64a66bf2d1ceb49063de663_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_e8eb65f3ddc97fe0630929832361c19979b6dfa6b64a66bf2d1ceb49063de663->leave($__internal_e8eb65f3ddc97fe0630929832361c19979b6dfa6b64a66bf2d1ceb49063de663_prof);

        
        $__internal_433807ae3c4c42ac87c34eaac32570356e8abc1f83e55cf6806c92f45cade17d->leave($__internal_433807ae3c4c42ac87c34eaac32570356e8abc1f83e55cf6806c92f45cade17d_prof);

    }

    // line 155
    public function block_body_javascript($context, array $blocks = array())
    {
        $__internal_1ff9d3241c5265701b4e5f8be1d9358d5dda288076f1b560a1b7e560bf7d66a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ff9d3241c5265701b4e5f8be1d9358d5dda288076f1b560a1b7e560bf7d66a2->enter($__internal_1ff9d3241c5265701b4e5f8be1d9358d5dda288076f1b560a1b7e560bf7d66a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_javascript"));

        $__internal_c9ea93abbe024f55f3412eb34fe77d317cd56e416ebb31758404e285bebfab7d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9ea93abbe024f55f3412eb34fe77d317cd56e416ebb31758404e285bebfab7d->enter($__internal_c9ea93abbe024f55f3412eb34fe77d317cd56e416ebb31758404e285bebfab7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_javascript"));

        
        $__internal_c9ea93abbe024f55f3412eb34fe77d317cd56e416ebb31758404e285bebfab7d->leave($__internal_c9ea93abbe024f55f3412eb34fe77d317cd56e416ebb31758404e285bebfab7d_prof);

        
        $__internal_1ff9d3241c5265701b4e5f8be1d9358d5dda288076f1b560a1b7e560bf7d66a2->leave($__internal_1ff9d3241c5265701b4e5f8be1d9358d5dda288076f1b560a1b7e560bf7d66a2_prof);

    }

    public function getTemplateName()
    {
        return "@EasyAdmin/default/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  775 => 155,  758 => 148,  748 => 144,  741 => 140,  737 => 138,  734 => 137,  725 => 136,  696 => 134,  687 => 133,  674 => 129,  665 => 128,  654 => 149,  652 => 148,  647 => 145,  644 => 136,  642 => 133,  638 => 131,  635 => 128,  626 => 127,  615 => 120,  613 => 117,  611 => 116,  602 => 115,  591 => 122,  589 => 115,  586 => 114,  577 => 113,  562 => 97,  559 => 96,  550 => 95,  540 => 103,  535 => 100,  533 => 95,  524 => 89,  519 => 86,  514 => 84,  511 => 83,  509 => 82,  505 => 81,  502 => 80,  500 => 79,  494 => 77,  485 => 76,  473 => 104,  471 => 76,  467 => 74,  464 => 73,  455 => 72,  442 => 66,  433 => 65,  424 => 64,  412 => 107,  410 => 72,  405 => 69,  403 => 64,  396 => 60,  392 => 58,  383 => 57,  372 => 151,  370 => 127,  365 => 124,  363 => 113,  358 => 110,  356 => 57,  353 => 56,  344 => 55,  311 => 53,  300 => 160,  291 => 158,  287 => 157,  284 => 156,  282 => 155,  278 => 153,  276 => 55,  266 => 53,  257 => 52,  236 => 30,  227 => 29,  215 => 43,  212 => 42,  209 => 29,  200 => 28,  185 => 25,  182 => 24,  173 => 23,  160 => 15,  154 => 13,  145 => 12,  127 => 10,  116 => 162,  114 => 52,  110 => 50,  105 => 48,  100 => 47,  98 => 46,  95 => 45,  93 => 28,  90 => 27,  88 => 23,  85 => 22,  76 => 20,  72 => 19,  69 => 18,  67 => 12,  62 => 10,  51 => 2,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"{{ app.request.locale|split('_')|first|default('en') }}\">
    <head>
        <meta charset=\"utf-8\">
        <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
        <meta name=\"robots\" content=\"noindex, nofollow, noarchive, nosnippet, noodp, noimageindex, notranslate, nocache\" />
        <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
        <meta name=\"generator\" content=\"EasyAdmin\" />

        <title>{% block page_title %}{{ block('content_title')|striptags|raw }}{% endblock %}</title>

        {% block head_stylesheets %}
            <link rel=\"stylesheet\" href=\"{{ asset('bundles/easyadmin/stylesheet/easyadmin-all.min.css') }}\">
            <style>
                {{ easyadmin_config('_internal.custom_css')|raw }}
            </style>
        {% endblock %}

        {% for css_asset in easyadmin_config('design.assets.css') %}
            <link rel=\"stylesheet\" href=\"{{ asset(css_asset) }}\">
        {% endfor %}

        {% block head_favicon %}
            {% set favicon = easyadmin_config('design.assets.favicon') %}
            <link rel=\"icon\" type=\"{{ favicon.mime_type }}\" href=\"{{ asset(favicon.path) }}\" />
        {% endblock %}

        {% block head_javascript %}
            {% block adminlte_options %}
                <script type=\"text/javascript\">
                    var AdminLTEOptions = {
                        animationSpeed: 'normal',
                        sidebarExpandOnHover: false,
                        enableBoxRefresh: false,
                        enableBSToppltip: false,
                        enableFastclick: false,
                        enableControlSidebar: false,
                        enableBoxWidget: false
                    };
                </script>
            {% endblock %}

            <script src=\"{{ asset('bundles/easyadmin/javascript/easyadmin-all.min.js') }}\"></script>
        {% endblock head_javascript %}

        {% if easyadmin_config('design.rtl') %}
            <link rel=\"stylesheet\" href=\"{{ asset('bundles/easyadmin/stylesheet/bootstrap-rtl.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('bundles/easyadmin/stylesheet/adminlte-rtl.min.css') }}\">
        {% endif %}
    </head>

    {% block body %}
    <body id=\"{% block body_id %}{% endblock %}\" class=\"easyadmin sidebar-mini {% block body_class %}{% endblock %} {{ app.request.cookies.has('_easyadmin_navigation_iscollapsed') ? 'sidebar-collapse' }}\">
        <div class=\"wrapper\">
        {% block wrapper %}
            <header class=\"main-header\">
            {% block header %}
                <nav class=\"navbar\" role=\"navigation\">
                    <a href=\"#\" class=\"sidebar-toggle\" data-toggle=\"offcanvas\" role=\"button\">
                        <span class=\"sr-only\">{{ 'toggle_navigation'|trans(domain = 'EasyAdminBundle') }}</span>
                    </a>

                    <div id=\"header-logo\">
                        {% block header_logo %}
                            <a class=\"logo {{ easyadmin_config('site_name')|length > 14 ? 'logo-long' }}\" title=\"{{ easyadmin_config('site_name')|striptags }}\" href=\"{{ path('easyadmin') }}\">
                                {{ easyadmin_config('site_name')|raw }}
                            </a>
                        {% endblock header_logo %}
                    </div>

                    <div class=\"navbar-custom-menu\">
                    {% block header_custom_menu %}
                        {% set _logout_path = easyadmin_logout_path() %}
                        <ul class=\"nav navbar-nav\">
                            <li class=\"dropdown user user-menu\">
                                {% block user_menu %}
                                    <span class=\"sr-only\">{{ 'user.logged_in_as'|trans(domain = 'EasyAdminBundle') }}</span>

                                    {% if app.user|default(false) == false %}
                                        <i class=\"hidden-xs fa fa-user-times\"></i>
                                        {{ 'user.anonymous'|trans(domain = 'EasyAdminBundle') }}
                                    {% elseif not _logout_path %}
                                        <i class=\"hidden-xs fa fa-user\"></i>
                                        {{ app.user.username|default('user.unnamed'|trans(domain = 'EasyAdminBundle')) }}
                                    {% else %}
                                        <div class=\"btn-group\">
                                            <button type=\"button\" class=\"btn\" data-toggle=\"dropdown\">
                                                <i class=\"hidden-xs fa fa-user\"></i>
                                                {{ app.user.username|default('user.unnamed'|trans(domain = 'EasyAdminBundle')) }}
                                            </button>
                                            <button type=\"button\" class=\"btn dropdown-toggle\" data-toggle=\"dropdown\" aria-expanded=\"false\">
                                                <span class=\"caret\"></span>
                                            </button>
                                            <ul class=\"dropdown-menu\" role=\"menu\">
                                                {% block user_menu_dropdown %}
                                                <li>
                                                    <a href=\"{{ _logout_path }}\"><i class=\"fa fa-sign-out\"></i> {{ 'user.signout'|trans(domain = 'EasyAdminBundle') }}</a>
                                                </li>
                                                {% endblock user_menu_dropdown %}
                                            </ul>
                                        </div>
                                    {% endif %}
                                {% endblock user_menu %}
                            </li>
                        </ul>
                    {% endblock header_custom_menu %}
                    </div>
                </nav>
            {% endblock header %}
            </header>

            <aside class=\"main-sidebar\">
            {% block sidebar %}
                <section class=\"sidebar\">
                    {% block main_menu_wrapper %}
                        {{ include([
                            _entity_config is defined ? _entity_config.templates.menu,
                            easyadmin_config('design.templates.menu'),
                            '@EasyAdmin/default/menu.html.twig'
                        ]) }}
                    {% endblock main_menu_wrapper %}
                </section>
            {% endblock sidebar %}
            </aside>

            <div class=\"content-wrapper\">
            {% block content %}
                {% block flash_messages %}
                    {{ include(_entity_config is defined ? _entity_config.templates.flash_messages : '@EasyAdmin/default/flash_messages.html.twig') }}
                {% endblock flash_messages %}

                <section class=\"content-header\">
                {% block content_header %}
                    <h1 class=\"title\">{% block content_title %}{% endblock %}</h1>
                {% endblock content_header %}
                {% block content_help %}
                    {% if _entity_config is defined and _entity_config[app.request.query.get('action')]['help']|default(false) %}
                        <div class=\"box box-widget help-entity\">
                            <div class=\"box-body\">
                                {{ _entity_config[app.request.query.get('action')]['help']|trans|raw }}
                            </div>
                        </div>
                    {% endif %}
                {% endblock content_help %}
                </section>

                <section id=\"main\" class=\"content\">
                    {% block main %}{% endblock %}
                </section>
            {% endblock content %}
            </div>
        {% endblock wrapper %}
        </div>

        {% block body_javascript %}{% endblock body_javascript %}

        {% for js_asset in easyadmin_config('design.assets.js') %}
            <script src=\"{{ asset(js_asset) }}\"></script>
        {% endfor %}
    </body>
    {% endblock body %}
</html>
", "@EasyAdmin/default/layout.html.twig", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\vendor\\javiereguiluz\\easyadmin-bundle\\src\\Resources\\views\\default\\layout.html.twig");
    }
}
