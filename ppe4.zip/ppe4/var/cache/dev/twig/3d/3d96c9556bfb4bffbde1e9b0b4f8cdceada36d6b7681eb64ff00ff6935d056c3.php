<?php

/* @WebProfiler/Profiler/header.html.twig */
class __TwigTemplate_23bbca4436cfb6def102d259b735ffbf1638ed43f4a72dd72841e98972763190 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d15b0e44c09daaaad8a00fb410e1337b51d200596fe42ffd317b34538a459efc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d15b0e44c09daaaad8a00fb410e1337b51d200596fe42ffd317b34538a459efc->enter($__internal_d15b0e44c09daaaad8a00fb410e1337b51d200596fe42ffd317b34538a459efc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        $__internal_0e4cc9eabea26be979ea29b7ff30c47187eddd33b55c7a23699b7c5513751cb0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e4cc9eabea26be979ea29b7ff30c47187eddd33b55c7a23699b7c5513751cb0->enter($__internal_0e4cc9eabea26be979ea29b7ff30c47187eddd33b55c7a23699b7c5513751cb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_d15b0e44c09daaaad8a00fb410e1337b51d200596fe42ffd317b34538a459efc->leave($__internal_d15b0e44c09daaaad8a00fb410e1337b51d200596fe42ffd317b34538a459efc_prof);

        
        $__internal_0e4cc9eabea26be979ea29b7ff30c47187eddd33b55c7a23699b7c5513751cb0->leave($__internal_0e4cc9eabea26be979ea29b7ff30c47187eddd33b55c7a23699b7c5513751cb0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "@WebProfiler/Profiler/header.html.twig", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\vendor\\symfony\\web-profiler-bundle\\Resources\\views\\Profiler\\header.html.twig");
    }
}
