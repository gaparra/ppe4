<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_1d2e11f24fef988cb7b1ddb874c6fa17407de29020b3fd788fbadbece1f41167 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffc853566f808bd8d3db85937cc31832e5b1695f1a5198845fcfc38e9a603803 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffc853566f808bd8d3db85937cc31832e5b1695f1a5198845fcfc38e9a603803->enter($__internal_ffc853566f808bd8d3db85937cc31832e5b1695f1a5198845fcfc38e9a603803_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_d117598fa9b78d7db39753dc80f55d8615f95188e1e9ebba7bef6cf487540d27 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d117598fa9b78d7db39753dc80f55d8615f95188e1e9ebba7bef6cf487540d27->enter($__internal_d117598fa9b78d7db39753dc80f55d8615f95188e1e9ebba7bef6cf487540d27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_ffc853566f808bd8d3db85937cc31832e5b1695f1a5198845fcfc38e9a603803->leave($__internal_ffc853566f808bd8d3db85937cc31832e5b1695f1a5198845fcfc38e9a603803_prof);

        
        $__internal_d117598fa9b78d7db39753dc80f55d8615f95188e1e9ebba7bef6cf487540d27->leave($__internal_d117598fa9b78d7db39753dc80f55d8615f95188e1e9ebba7bef6cf487540d27_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "C:\\Users\\g.parra\\projetSf4\\tpsecurite\\vendor\\symfony\\twig-bundle\\Resources\\views\\images\\icon-minus-square.svg");
    }
}
